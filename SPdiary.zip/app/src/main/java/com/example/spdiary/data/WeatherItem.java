package com.example.spdiary.data;

public class WeatherItem {

    public int hour;
    public int day;
    public double temp;
    public double tmx;
    public double tmn;
    public int sky;
    public int pty;
    public String wfKor;
    public String wfEn;
    public int pop;
    public double r12;
    public double s12;
    public double ws;
    public int wd;
    public String wdKor;
    public String wdEn;
    public int reh;
    public double r06;
    public double s06;

}
