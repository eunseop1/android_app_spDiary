package com.example.spdiary.data;

public class WeatherHeader {

    public String tm;
    public String ts;
    public String x;
    public String y;

}
