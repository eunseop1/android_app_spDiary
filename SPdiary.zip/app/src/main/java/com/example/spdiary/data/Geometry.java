package com.example.spdiary.data;

public class Geometry {

    public GeometryLocation location;

}
