package com.example.spdiary

data class Quote (
        val quote: String ,
        val name : String
)