package com.example.spdiary.data;

public class GeocodeItem {

    public String formatted_address;
    public Geometry geometry;

}
