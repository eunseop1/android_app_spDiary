package com.example.spdiary.data;

import java.util.ArrayList;

public class GeocodeResult {

    public ArrayList<GeocodeItem> results = new ArrayList<GeocodeItem>();
    public String status;

}
