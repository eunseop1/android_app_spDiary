package com.example.spdiary;

public interface OnRequestListener {
    public void onRequest(String command);
}
